function my(){
  var ul = document.getElementById('ul'); 
if(ul.style.display === "block"){
  ul.style.display = "none"
}
else{ul.style.display = "block"}
}