
<?php 
    $result = "";
    $error  = "";
if(isset($_POST['submit']))
{
    require 'phpmailer/PHPMailerAutoload.php';
    $mail = new PHPMailer;
    //smtp settings
    $mail->isSMTP(); // send as HTML
    $mail->Host = "smtp.gmail.com"; // SMTP servers
    $mail->SMTPAuth = true; // turn on SMTP authentication
    $mail->Username = "vatsalrox5@gmail.com"; // Your mail
    $mail->Password = 'vatsal123'; // Your password mail
    $mail->Port = 587; //specify SMTP Port
    $mail->SMTPSecure = 'tls';                               
    $mail->setFrom($_POST['email'],$_POST['name']);
    $mail->addAddress('vatsalrox5@gmail.com');
    $mail->addReplyTo($_POST['email'],$_POST['name']);
    $mail->isHTML(true);
    $mail->Subject='Form Submission:' .$_POST['subject'];
    $mail->Body='<h3>Name :'.$_POST['name'].'<br> Email: '.$_POST['email'].'<br>Message: '.$_POST['message'].'</h3>';
    if(!$mail->send())
    {
        $error = "Something went worng. Please try again.";
    }
    else 
    {
        $result="Thanks\t" .$_POST['name']. " Your Request will be looked into &#x1F600;	";
    }
}


?>


<html>
    <head>
<link rel="stylesheet" href="../css/style.css" type="text/css">
<title>Idiot Cinema</title>
<link rel="icon" href="../images/icon.png" type="png">   
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<link href="https://fonts.googleapis.com/css2?family=PT+Sans&display=swap" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="Hub of the latest movies and latest series in Hindi and English, updated, request and premium services available too ">


</head>
   <body>
       
       <nav>
        <img src="../images/logo.png">
        <div id="burger" onclick="my()">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
        <ul id="ul" class="w3-animate-top">
            <li><a href="../index.html">HOME</a></li>
            <li><a href="../movies/hindi.html">MOVIES</a></li>
            <li><a href="../series/hindi.html">SERIES</a></li>
            <li><a href="index.php">CONTACT</a></li>
            <li><a href="#" id="active">REQUEST</a></li>

        </ul>
        
       </nav>
   
    
    <div id="ann"  >
         Kindly do not search for the website instead bookmark it or type full <a href="http://www.idiotcinema.xyz"class="sitename">IdiotCinema.xyz </a> in the address bar 
    </div>
    <div id="hr1"></div>
    <h2 class="text-center text-white"> <?=$result; ?></h2>
    <h2 class="text-center text-danger"> <?=$error; ?></h2>
    <form action="" method="post" id="form">
        
                    <label for="inputName">Name</label>
                    <input type="text" class="input-field"id="name" name="name" placeholder="Enter Full" required>
              
            
            
                <label for="inputEmail">Email</label>
                <input type="email" class="input-field" id="Email" name="email" placeholder="Enter Email" required>
            
        
               
  
        <label for="inputSubject">URL/full name of the Movie/TV show</label>
        <input type="text" class="input-field" id="Subject"​ name="subject" placeholder="Enter Subject" required>
   
    
        <label for="inputMessage">Your Request</label>
        <textarea class="input-field-area" id="msg" name="message" rows="5" placeholder="Enter Message..." required></textarea>
   
   
        <button type="submit" name="submit" class="btn"><i class="fa fa-paper-plane"></i> Submit</button>
     
</form>
        <div id="hr1"></div>
    <hr id="hhr">
    
    <div id="footer">
        &#169;IdiotCinema.xyz - 2020
    </div>
    <script type="text/javascript" src="../script1.js"></script>
    </body>
</html>